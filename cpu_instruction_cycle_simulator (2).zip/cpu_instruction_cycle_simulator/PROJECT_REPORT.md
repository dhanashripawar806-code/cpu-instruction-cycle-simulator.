# COA–CO5 Mini Project Report
## CPU Instruction Cycle Simulator: Fetch, Decode, and Execute

**Student:** Dhanashri Sandip Pawar  
**University:** Sanjivani University, Kopargaon, Maharashtra, India  
**Department:** School of Engineering & Technology  
**Course:** Integrated B.Tech CSE  
**Subject:** Computer Organization and Architecture (COA)  
**Assessment:** CO5 Micro Project  
**Academic Year:** 2026–27  
**Submission deadline:** 22 October 2026

## 1. Introduction
The CPU Instruction Cycle Simulator is a browser-based educational application that demonstrates how a simplified processor fetches, decodes, and executes instructions. It displays the Program Counter (PC), Instruction Register (IR), Accumulator (ACC), Memory Address Register (MAR), and eight memory locations. Users can load an instruction, advance through each stage, run the remaining stages, and inspect register and memory changes.

The project is implemented with HTML5, CSS3, and vanilla JavaScript. It runs locally in a modern browser and does not require a server or database.

## 2. Objectives
- Understand the Fetch–Decode–Execute instruction cycle.
- Observe the role of PC, IR, MAR, ACC, and memory.
- Simulate LOAD, ADD, SUB, STORE, JUMP, and HALT.
- Show state changes after each stage.
- Validate inputs and display clear error messages.
- Practise building an interactive, responsive web application.

## 3. Tools and Technologies
- HTML5: page structure and controls.
- CSS3: responsive layout, stage indicators, register cards, and memory display.
- Vanilla JavaScript: CPU state, instruction processing, validation, and log updates.
- Modern web browser: local execution.

## 4. System design
### Registers
- **PC (Program Counter):** address of the instruction to fetch next.
- **IR (Instruction Register):** currently fetched instruction.
- **MAR (Memory Address Register):** memory address being accessed.
- **ACC (Accumulator):** stores arithmetic results and loaded values.
- **Memory:** eight locations, numbered 0–7.

### Instruction set
| Instruction | Meaning |
|---|---|
| `LOAD n` | ACC ← MEM[n] |
| `ADD n` | ACC ← ACC + MEM[n] |
| `SUB n` | ACC ← ACC − MEM[n] |
| `STORE n` | MEM[n] ← ACC |
| `JUMP n` | PC ← n |
| `HALT` | Stop instruction processing |

For LOAD, ADD, and SUB, the target memory location must contain numeric data. STORE replaces a location with the ACC value. JUMP changes the next PC to its target. HALT stops execution without fetching another instruction.

## 5. Methodology / algorithm
1. Validate the user-supplied opcode, operand, initial PC, and initial ACC.
2. Load the selected instruction into the memory location indicated by the initial PC.
3. **Fetch:** copy PC into MAR and copy the memory instruction into IR. Prepare sequential next PC as `(PC + 1) % 8`.
4. **Decode:** check that the opcode is supported and its operand is valid. For LOAD, ADD, and SUB, verify the target contains numeric data.
5. **Execute:** perform the operation and update ACC or memory. JUMP overrides the sequential next PC. HALT stops the simulator.
6. Update the display and append a log entry.
7. Repeat for subsequent instructions if present, until HALT or an error occurs.

## 6. Flowchart
```text
        ┌─────────────────────┐
        │ Start / Load input  │
        └──────────┬──────────┘
                   ▼
        ┌─────────────────────┐
        │ Fetch: MAR ← PC      │
        │ IR ← MEM[MAR]        │
        └──────────┬──────────┘
                   ▼
        ┌─────────────────────┐
        │ Decode opcode/arg   │
        └──────────┬──────────┘
                   ▼
        ┌─────────────────────┐
        │ Execute instruction │
        └──────────┬──────────┘
                   ▼
        ┌─────────────────────┐
        │ HALT instruction?   │
        └──────┬────────┬─────┘
             Yes        No
              ▼          ▼
        ┌──────────┐  ┌─────────────────┐
        │   Stop   │  │ Update PC/state │
        └──────────┘  └────────┬────────┘
                              └─────► Fetch
```

## 7. Sample input and expected output
The built-in sample memory initially contains:
- Address 0: `LOAD 3`
- Address 1: `ADD 4`
- Address 2: `STORE 5`
- Address 3: `HALT`
- Address 4: numeric value `7`
- Address 5: numeric value `0`
- Address 6: numeric value `0`
- Address 7: numeric value `0`

For a direct single-instruction demonstration, set initial ACC to 10, initial PC to 0, select `ADD`, set operand to 4, and click **Load Instruction**. Address 0 becomes `ADD 4`; address 4 contains 7. After Fetch, Decode, and Execute, ACC becomes 17 and PC becomes 1.

## 8. Test cases
| Test | Input / action | Expected result |
|---|---|---|
| LOAD | ACC=10, PC=0, LOAD 4; MEM[4]=7 | ACC=7; PC=1 |
| ADD | ACC=10, PC=0, ADD 4; MEM[4]=7 | ACC=17; PC=1 |
| SUB | ACC=10, PC=0, SUB 4; MEM[4]=7 | ACC=3; PC=1 |
| STORE | ACC=10, PC=0, STORE 5 | MEM[5]=10; PC=1 |
| JUMP | PC=0, JUMP 6 | PC=6 |
| HALT | PC=0, HALT | CPU stops; PC stays at 0 |
| Invalid operand | operand = 9 | Validation message; instruction is not loaded |
| Missing instruction | reset, then try to step without loading | No execution; user is asked to load an instruction |

## 9. JavaScript logic
The application stores the simulated CPU state in a JavaScript object containing `pc`, `ir`, `acc`, `mar`, and `memory`. The `phase` variable tracks the current stage. The `step()` function executes one stage at a time:
- During Fetch it reads the instruction from memory and fills MAR and IR.
- During Decode it validates the opcode and operand.
- During Execute it applies the selected operation and updates the CPU state.

`render()` updates the displayed registers, memory, and active stage. `addLog()` records the events. `validateForm()` checks that user inputs are whole numbers within the permitted ranges. The `runInstruction()` function calls `step()` up to three times to complete the current instruction.

## 10. Limitations
This is a simplified teaching model and not a physical CPU emulator. It uses a shared eight-location memory for instructions and data, has no binary opcode encoding, flags, cache, interrupts, clock timing, or actual hardware bus transfers. Sequential PC advancement wraps from address 7 to 0. Only one custom instruction is loaded at a time; users can inspect and run its cycle, then load another instruction. This interface is designed to demonstrate individual instruction cycles rather than automatically run a complete program.

## 11. Result
The project provides an interactive visual demonstration of Fetch, Decode, and Execute. It exposes changes in PC, IR, MAR, ACC, and memory, and records a step-by-step execution log. The expected behavior can be checked using the listed test cases.

## 12. Conclusion
The CPU Instruction Cycle Simulator connects COA concepts with a practical frontend project. It helps learners see how instructions are fetched from memory, decoded, and executed, and how registers and memory change as a result. The project also demonstrates input validation, event-driven JavaScript, and responsive web design.

## 13. Demonstration script
1. Introduce the project and explain that it is a software model, not real hardware.
2. Point out PC, IR, MAR, ACC, and the eight memory cells.
3. Set ACC=10, PC=0, select ADD, and set operand=4.
4. Click **Load Instruction** and explain where the instruction is placed.
5. Click **Next Step** three times, explaining Fetch, Decode, and Execute.
6. Show ACC=17 and PC=1; point to the execution log.
7. Demonstrate JUMP or STORE, then demonstrate HALT.
8. Enter an invalid operand and show the validation message.
9. Summarize the model's limitations.

## 14. Viva questions and answers
**Q1. What is an instruction cycle?**  
It is the sequence of steps a CPU follows to fetch, decode, and execute an instruction.

**Q2. What does the Program Counter do?**  
It holds the address of the instruction to fetch next.

**Q3. What is the Instruction Register?**  
It holds the instruction currently being processed.

**Q4. What is the MAR?**  
The Memory Address Register holds the address of a memory location being accessed.

**Q5. What is the role of the accumulator?**  
It stores values used by arithmetic operations and their results in this simplified model.

**Q6. What does FETCH do in this project?**  
It copies PC into MAR and reads the instruction at that address into IR.

**Q7. What is the difference between JUMP and normal PC advancement?**  
Normal execution selects the next sequential address; JUMP sets PC to the specified target.

**Q8. What does HALT do?**  
It stops further instruction processing.

**Q9. Why is JavaScript used?**  
It handles user interactions, simulates register and memory updates, validates input, and refreshes the display.

**Q10. Is this a real CPU emulator?**  
No. It is a simplified educational software simulation and does not execute machine instructions on physical CPU hardware.

## 15. Assessment-rubric alignment
- **Concept and design (2 marks):** clear instruction-cycle stages and register model.
- **Simulation correctness (4 marks):** implemented instruction behavior, PC rules, and validation.
- **Features and customisation (2 marks):** editable instruction, operands, initial registers, logs, and reset.
- **Demonstration and explanation (2 marks):** sample test cases, flowchart, and viva preparation.
