# CPU Instruction Cycle Simulator

## Run locally
1. Download/extract this folder.
2. Open `index.html` in Chrome, Edge, Firefox, or another modern browser.
3. Select an instruction and operand, set initial ACC and PC, and click **Load Instruction**.
4. Click **Next Step** once for each stage, or **Run Instruction** to finish the current instruction.
5. Click **Reset** to restore the sample memory and current input-based starting register values.

No server, database, package installation, or internet connection is required.

## Files
- `index.html` — complete application (HTML, CSS, JavaScript)
- `PROJECT_REPORT.md` — project report, flowchart, tests, demo script, and viva Q&A

## Important model notes
- Memory has eight addresses (0–7), shared by instructions and numeric data.
- LOAD/ADD/SUB need numeric data at the referenced address.
- PC wraps around from 7 to 0 for sequential execution.
- This is a simplified educational simulation, not physical CPU hardware.
